from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
import time
import os
from transcriber.transcriber import transcribe_file

# Define the directory to watch
WATCH_DIRECTORY = "C:/Users/MOHAN/Desktop/AutomatedTranscriptionSystem/watch_folder"

class FileHandler(FileSystemEventHandler):
    def on_created(self, event):
        if not event.is_directory and event.src_path.lower().endswith((".mp3", ".wav", ".mp4", ".mkv", ".mov", ".flv", ".aac", ".m4a")):
            print(f"New file detected: {event.src_path}")
            transcribe_file(event.src_path)

def monitor_directory():
    if not os.path.exists(WATCH_DIRECTORY):
        print(f"Error: The directory {WATCH_DIRECTORY} does not exist.")
        return
    
    observer = Observer()
    event_handler = FileHandler()
    observer.schedule(event_handler, WATCH_DIRECTORY, recursive=True)
    
    print(f"Monitoring directory: {WATCH_DIRECTORY}")
    
    observer.start()
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()
        print("Monitoring stopped.")
    observer.join()
