WATCH_DIRECTORY = "./media"
OUTPUT_DIRECTORY = "./output"
PROCESSED_FILES = "processed_files.json"