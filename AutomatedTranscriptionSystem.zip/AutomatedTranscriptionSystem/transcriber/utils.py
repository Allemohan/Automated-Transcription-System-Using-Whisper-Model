import os

def ensure_directories():
    if not os.path.exists("./output"):
        os.makedirs("./output")