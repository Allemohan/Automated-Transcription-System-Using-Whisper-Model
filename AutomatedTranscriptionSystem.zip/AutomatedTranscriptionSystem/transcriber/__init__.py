import os
import time
import whisper
import json
import shutil
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

# Configuration
WATCH_DIRECTORY = "./media"  # Directory to monitor
OUTPUT_DIRECTORY = "./output"  # Directory to save transcriptions
PROCESSED_FILES = "processed_files.json"  # File tracking processed media

# Load or create file tracking
if os.path.exists(PROCESSED_FILES):
    with open(PROCESSED_FILES, "r") as f:
        processed_files = json.load(f)
else:
    processed_files = {}

# Load Whisper model
model = whisper.load_model("base")

def transcribe_file(file_path):
    """Transcribe audio/video using Whisper and save output."""
    if file_path in processed_files:
        print(f"Skipping {file_path}, already processed.")
        return
    
    print(f"Transcribing: {file_path}")
    result = model.transcribe(file_path)
    text_output_path = os.path.join(OUTPUT_DIRECTORY, os.path.basename(file_path) + ".txt")
    
    with open(text_output_path, "w") as f:
        f.write(result["text"])
    
    processed_files[file_path] = True
    with open(PROCESSED_FILES, "w") as f:
        json.dump(processed_files, f)
    
    print(f"Transcription saved: {text_output_path}")

class FileHandler(FileSystemEventHandler):
    """Handles new files added to the directory."""
    def on_created(self, event):
        if not event.is_directory and event.src_path.lower().endswith((".mp3", ".wav", ".mp4", ".mkv", ".mov", ".flv", ".aac", ".m4a")):
            transcribe_file(event.src_path)

def monitor_directory():
    """Monitors directory for new files in real time."""
    observer = Observer()
    event_handler = FileHandler()
    observer.schedule(event_handler, WATCH_DIRECTORY, recursive=True)
    observer.start()
    print(f"Monitoring directory: {WATCH_DIRECTORY}")
    
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()
    observer.join()

if __name__ == "__main__":
    if not os.path.exists(OUTPUT_DIRECTORY):
        os.makedirs(OUTPUT_DIRECTORY)
    monitor_directory()
