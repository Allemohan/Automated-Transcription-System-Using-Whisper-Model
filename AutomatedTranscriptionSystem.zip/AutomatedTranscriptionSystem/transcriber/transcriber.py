import whisper
import os
import json
from transcriber.config import OUTPUT_DIRECTORY, PROCESSED_FILES

model = whisper.load_model("base")

if os.path.exists(PROCESSED_FILES):
    with open(PROCESSED_FILES, "r") as f:
        processed_files = json.load(f)
else:
    processed_files = {}

def transcribe_file(file_path):
    if file_path in processed_files:
        return
    result = model.transcribe(file_path)
    text_output_path = os.path.join(OUTPUT_DIRECTORY, os.path.basename(file_path) + ".txt")
    with open(text_output_path, "w") as f:
        f.write(result["text"])
    processed_files[file_path] = True
    with open(PROCESSED_FILES, "w") as f:
        json.dump(processed_files, f)