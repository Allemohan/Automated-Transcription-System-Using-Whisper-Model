from transcriber.file_watcher import monitor_directory
from transcriber.utils import ensure_directories

if __name__ == "__main__":
    ensure_directories()
    monitor_directory()